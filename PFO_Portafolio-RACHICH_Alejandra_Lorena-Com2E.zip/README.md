# Personal_Page
Modelo de portfolio en desarrollo, utilizando HTML, CSS y JavaScript. <br> Práctica formativa para la materia Front End de la Tecnicatura superior en desarrollo de software <br>
Enlace a página:  https://alexa-2k.github.io/PFO_Portfolio/

Portfolio prototype under development, using HTML, CSS, and JavaScript.<br> Educational project for the Front-End course in the Software Development Technical Degree.
Page link (English version): https://alexa-2k.github.io/PFO_Portfolio/index-eng.html
